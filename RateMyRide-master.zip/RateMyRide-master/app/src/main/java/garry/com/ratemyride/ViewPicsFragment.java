package garry.com.ratemyride;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

public class ViewPicsFragment extends Fragment {
    private Car car;

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_pics, container, false);
        final ImageButton ib = view.findViewById(R.id.carPicIB);
        Glide.with(ib.getContext())
                .load(car.getCarImageUrl(0))
                .placeholder(R.drawable.blue_gradient_background)
                .fitCenter()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(ib);
        ib.setOnClickListener(v -> {

            if (car.getCurrentCar() + 1 > car.getCarImageUrls().size() - 1) {
                car.setCurrentCar(0);
            } else {
                car.setCurrentCar(car.getCurrentCar() + 1);
            }
            Glide.with(ib.getContext())
                    .load(car.getCarImageUrl(car.getCurrentCar()))
                    .placeholder(R.drawable.blue_gradient_background)
                    .fitCenter()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(ib);

        });
        return view;
    }

    public void setCar(Car car) {
        this.car = car;
    }
}

