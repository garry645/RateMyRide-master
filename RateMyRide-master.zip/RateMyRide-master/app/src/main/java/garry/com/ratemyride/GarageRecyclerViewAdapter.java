package garry.com.ratemyride;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.android.gms.ads.AdView;

public class GarageRecyclerViewAdapter extends FirestoreRecyclerAdapter<Car, GarageRecyclerViewAdapter.GarageCarHolder> {

    GarageRecyclerViewAdapter(@NonNull FirestoreRecyclerOptions<Car> options) {
        super(options);
    }


    @SuppressLint("SetTextI18n")
    @Override
    protected void onBindViewHolder(@NonNull final GarageRecyclerViewAdapter.GarageCarHolder holder, int position, @NonNull final Car model) {


        if (model.getCarImageUrls().size() > 0) {
            holder.vUsername.setText(model.owner.username);
            Glide.with(holder.vCarImage.getContext())
                    .load(model.getCarImageUrl(model.getCurrentCar()))
                    .placeholder(R.drawable.blue_gradient_background)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .fitCenter()
                    .into(holder.vCarImage);
            if (model.getCarImageUrls().size() > 1) {
                Glide.with(holder.vCarImage.getContext())
                        .load(model.getCarImageUrl(model.getCurrentCar() + 1))
                        .preload();
            }
            holder.vMake.setText("Make: " + model.getMake());
            holder.vModel.setText("Model: " + model.getModel());
            holder.vyear.setText("Year: " + String.valueOf(model.getYear()));

            holder.vCarImage.setOnClickListener(v -> {

                if (model.getCurrentCar() + 1 > model.getCarImageUrls().size() - 1) {
                    model.setCurrentCar(0);
                } else {
                    model.setCurrentCar(model.getCurrentCar() + 1);
                }
                Glide.with(holder.vCarImage.getContext())
                        .load(model.getCarImageUrl(model.getCurrentCar()))
                        .placeholder(R.drawable.blue_gradient_background)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .fitCenter()
                        .into(holder.vCarImage);
                if (model.getCurrentCar() + 1 > model.getCarImageUrls().size() - 1) {
                    Glide.with(holder.vCarImage.getContext())
                            .load(model.getCarImageUrl(0))
                            .preload();

                } else {
                    Glide.with(holder.vCarImage.getContext())
                            .load(model.getCarImageUrl(model.getCurrentCar() + 1))
                            .preload();
                }

            });

        } else {
            getSnapshots().getSnapshot(position).getReference().delete();
        }

    }

    @NonNull
    @Override
    public GarageRecyclerViewAdapter.GarageCarHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.garage_card_layout,
                parent, false);
        return new GarageRecyclerViewAdapter.GarageCarHolder(v);
    }


    class GarageCarHolder extends RecyclerView.ViewHolder {
        TextView vUsername;
        ImageButton vCarImage;
        TextView vMake;
        TextView vModel;
        TextView vyear;
        AdView mAd;

        GarageCarHolder(@NonNull View itemViewIn) {
            super(itemViewIn);
            vUsername = itemViewIn.findViewById(R.id.txtUsername);
            vCarImage = itemViewIn.findViewById(R.id.carImageButton);
            vMake = itemViewIn.findViewById(R.id.txtMake);
            vModel = itemViewIn.findViewById(R.id.txtModel);
            vyear = itemViewIn.findViewById(R.id.txtYear);
            mAd = itemViewIn.findViewById(R.id.adView);
        }
    }
}
