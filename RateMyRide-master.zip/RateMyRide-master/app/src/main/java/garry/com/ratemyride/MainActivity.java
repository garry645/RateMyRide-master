package garry.com.ratemyride;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Objects;

import static garry.com.ratemyride.LoginActivity.EMAIL_EXTRA;

public class MainActivity extends AppCompatActivity {

    protected FirebaseFirestore db = FirebaseFirestore.getInstance();
    protected static CollectionReference ratersReference;
    protected static CollectionReference carsReference;
    protected static Owner owner;
    protected static String email;


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ratersReference = db.collection("raters");
        carsReference = db.collection("cars");
        Intent intent = getIntent();
        email = intent.getStringExtra(SignUpActivity.EMAIL_EXTRA);
        ratersReference.document(email).get().addOnCompleteListener(task -> owner = Objects.requireNonNull(task.getResult()).toObject(Owner.class));

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_garage);
        bottomNav.setOnNavigationItemSelectedListener(navListener);


        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container2,
                new GarageFragment()).commit();

    }

    protected static void setOwner(Owner ownerIn) {
        owner = ownerIn;
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            menuItem -> {
                Fragment selectedFragment = null;
                switch (menuItem.getItemId()) {
                    case R.id.nav_feed:
                        selectedFragment = new FeedFragment();
                        break;

                    case R.id.nav_garage:
                        selectedFragment = new GarageFragment();
                        break;

                    case R.id.nav_rated:
                        selectedFragment = new RatedFragment();
                        break;
                }
                assert selectedFragment != null;
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container2,
                        selectedFragment).commit();

                return true;
            };

    public void openNewCarPage(View view) {
        Intent intent = new Intent(this, AddingCarActivity.class);
        intent.putExtra(EMAIL_EXTRA, email);
        startActivity(intent);
    }
}
