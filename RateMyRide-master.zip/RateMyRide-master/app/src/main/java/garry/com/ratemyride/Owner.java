package garry.com.ratemyride;

public class Owner {

    private String email;
    public String username;
    private int ratingsLeft;
    private int raterscore;

    public Owner() {

    }

    public Owner(String emailIn, String usernameIn) {
        this.email = emailIn;
        this.username = usernameIn;
        this.raterscore = 1;
        this.ratingsLeft = 30;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public int getRaterscore() {
        return raterscore;
    }

    public int getRatingsLeft() {
        return ratingsLeft;
    }

    public void setRatingsLeft() {
        this.ratingsLeft--;
    }

    public void resetRatingsLeft() {
        this.ratingsLeft = 30;
    }

}
