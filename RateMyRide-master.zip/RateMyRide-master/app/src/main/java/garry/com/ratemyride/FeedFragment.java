package garry.com.ratemyride;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.Query;

import java.util.Date;
import java.util.Objects;

import static garry.com.ratemyride.MainActivity.email;
import static garry.com.ratemyride.MainActivity.owner;
import static garry.com.ratemyride.MainActivity.ratersReference;

public class FeedFragment extends Fragment {

    private CarAdapter adapter;
    static DocumentReference user;
    static DocumentSnapshot userSnapshot;


    public FeedFragment() {
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_feed, container, false);

        user = ratersReference.document(email);
        user.get().addOnCompleteListener(task -> {
                    userSnapshot = task.getResult();
                    Date oldDate = Objects.requireNonNull(Objects.requireNonNull(userSnapshot).getTimestamp("Timestamp")).toDate();
                    //Date nextDate = new Date(oldDate.getTime() + 86400000);
                    oldDate.setTime(oldDate.getTime() + 10000);
                    FieldValue timestamp = FieldValue.serverTimestamp();
                    user.update("Timestamp", timestamp);//.addOnCompleteListener(v -> {
                    Date currentDate = Objects.requireNonNull(userSnapshot.getTimestamp("Timestamp")).toDate();
                    if (currentDate.after(oldDate)) {
                        user.update("ratingsLeft", 30);
                        owner.resetRatingsLeft();
                    }
                    Log.i("worked", currentDate.toString());
                }
        );

        Query query = user.collection("nonRatedCars").whereEqualTo("rated", false).limit(31);

        FirestoreRecyclerOptions<NonRatedCar> options = new FirestoreRecyclerOptions.Builder<NonRatedCar>()
                .setQuery(query, NonRatedCar.class)
                .build();

        RecyclerView recyclerView = view.findViewById(R.id.feed_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CarAdapter(options);
        recyclerView.setAdapter(adapter);

        new ItemTouchHelper(
                new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder
                            viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                        if (i == ItemTouchHelper.LEFT) {
                            if (owner.getRatingsLeft() > 0) {
                                viewHolder.itemView.setVisibility(View.GONE);
                                adapter.rateCarNegatively(viewHolder.getAdapterPosition(), owner.getRaterscore());
                                owner.setRatingsLeft();
                                user.update("ratingsLeft", owner.getRatingsLeft());
                            } else {
                                Toast.makeText(getContext(), "Out Of Ratings! Return Tomorrow for More!" + owner.getRatingsLeft(), Toast.LENGTH_LONG).show();
                            }
                        }

                        if (i == ItemTouchHelper.RIGHT) {
                            if (owner.getRatingsLeft() > 0) {
                                viewHolder.itemView.setVisibility(View.GONE);
                                adapter.rateCarPositively(viewHolder.getAdapterPosition(), owner.getRaterscore());
                                owner.setRatingsLeft();
                                user.update("ratingsLeft", owner.getRatingsLeft());
                            } else {
                                Toast.makeText(getContext(), "Out Of Ratings! Return Tomorrow for More!" + owner.getRatingsLeft(), Toast.LENGTH_LONG).show();
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }
                }).attachToRecyclerView(recyclerView);
        return view;
    }


    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }



}
