package garry.com.ratemyride;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Objects;

public class AddingCarActivity extends AppCompatActivity {



    protected static Owner owner;
    protected static Car car;
    protected String email;
    protected static CollectionReference ratersReference;
    protected static CollectionReference carsReference;
    protected static DocumentReference usersDocumentRef;
    protected FirebaseFirestore db;
    protected static FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_car);

        Intent intent = getIntent();
        email = intent.getStringExtra(SignUpActivity.EMAIL_EXTRA);
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        ratersReference = db.collection("raters");
        carsReference = db.collection("cars");



        usersDocumentRef = ratersReference.document(email);
        usersDocumentRef.get().addOnCompleteListener(task -> {
            owner = Objects.requireNonNull(task.getResult()).toObject(Owner.class);
            getSupportFragmentManager().beginTransaction().replace(R.id.add_ride_fragment_container,
                    new AddingCarFragment()).commit();
        });


    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if (v instanceof EditText) {
                Rect outRect = new Rect();
                v.getGlobalVisibleRect(outRect);
                if (!outRect.contains((int) event.getRawX(), (int) event.getRawY())) {
                    v.clearFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    assert imm != null;
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            }
        }
        return super.dispatchTouchEvent(event);
    }

    protected static Car createNewCar(Owner owner, String dbIDIn, String makeIn, String modelIn,
                                      int yearIn) {
        //creates a new car with given owner, make, model, year, and then initializes carImage array to null
        car = new Car(owner, makeIn, modelIn, yearIn, 0, 0, 0, dbIDIn);
        return car;
    }
}


//**********************************************************************************************

    /*private EditText makeET;
    private EditText modelET;
    private EditText yearET;
    private Button addCarButton;

    private static final int PICK_IMAGE_REQUEST1 = 1;
    private static final int PICK_IMAGE_REQUEST2 = 2;
    private static final int PICK_IMAGE_REQUEST3 = 3;
    private static final int PICK_IMAGE_REQUEST4 = 4;
    private static final int PICK_IMAGE_REQUEST5 = 5;
    private static final int PICK_IMAGE_REQUEST6 = 6;
    private static final int PICK_IMAGE_REQUEST7 = 7;
    private static final int PICK_IMAGE_REQUEST8 = 8;
    private static final int PICK_IMAGE_REQUEST9 = 9;
    private static final int PICK_IMAGE_REQUEST10 = 10;
    private ImageButton carImage1;
    private ImageButton carImage2;
    private ImageButton carImage3;
    private ImageButton carImage4;
    private ImageButton carImage5;
    private ImageButton carImage6;
    private ImageButton carImage7;
    private ImageButton carImage8;
    private ImageButton carImage9;
    private ImageButton carImage10;

    private StorageReference mStorageRef;

    private ArrayList<Uri> uris;
    private String usernameIn;
    private String emailIn;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference carsdb = db.collection("cars");
    private CollectionReference dbRaters = db.collection("raters");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding_car);

        makeET = findViewById(R.id.makeET2);
        modelET = findViewById(R.id.modelET);
        yearET = findViewById(R.id.yearET);
        addCarButton = findViewById(R.id.add_car_button);

        Intent intent = getIntent();
        emailIn = intent.getStringExtra(SignUpActivity.EMAIL_EXTRA);
        DocumentReference doc = dbRaters.document(emailIn);
        doc.get().addOnSuccessListener(documentSnapshot -> {
            Owner owner = documentSnapshot.toObject(Owner.class);
            assert owner != null;
            usernameIn = owner.getUsername();
        });


        uris = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            uris.add(i, null);
        }
        mStorageRef = FirebaseStorage.getInstance().getReference("uploads");
        loadImageButtons();
    }

    public void addNewCar(View view) {
        addCarButton.setEnabled(false);
        Owner owner = createNewOwner();

        DocumentReference newCarDbRef = carsdb.document();
        String docRefId = newCarDbRef.getId();
        // NonRatedCar NRCarIn = createNewNonRatedCar(owner, docRefId);
        Car carIn = createNewCar(owner, docRefId);
        newCarDbRef.set(carIn);

        addFiles(dbRaters, carIn, newCarDbRef);
    }

    private Car createNewCar(Owner owner, String dbIDIn) {
        String make = makeET.getText().toString();
        String model = modelET.getText().toString();
        int year = Integer.parseInt(yearET.getText().toString());
        return new Car(owner, make, model, year, 0, 0, 0, dbIDIn);
    }

    private void loadImageButtons() {
        carImage1 = findViewById(R.id.carImage1);
        carImage2 = findViewById(R.id.carImage2);
        carImage3 = findViewById(R.id.carImage3);
        carImage4 = findViewById(R.id.carImage4);
        carImage5 = findViewById(R.id.carImage5);
        carImage6 = findViewById(R.id.carImage6);
        carImage7 = findViewById(R.id.carImage7);
        carImage8 = findViewById(R.id.carImage8);
        carImage9 = findViewById(R.id.carImage9);
        carImage10 = findViewById(R.id.carImage10);
        carImage2.setVisibility(View.INVISIBLE);
        carImage3.setVisibility(View.INVISIBLE);
        carImage4.setVisibility(View.INVISIBLE);
        carImage5.setVisibility(View.INVISIBLE);
        carImage6.setVisibility(View.INVISIBLE);
        carImage7.setVisibility(View.INVISIBLE);
        carImage8.setVisibility(View.INVISIBLE);
        carImage9.setVisibility(View.INVISIBLE);
        carImage10.setVisibility(View.INVISIBLE);
        carImage1.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST1));
        carImage2.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST2));
        carImage3.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST3));
        carImage4.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST4));
        carImage5.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST5));
        carImage6.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST6));
        carImage7.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST7));
        carImage8.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST8));
        carImage9.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST9));
        carImage10.setOnClickListener(v -> openFileChooser(PICK_IMAGE_REQUEST10));
    }

    private void openFileChooser(int imageRequestIn) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, imageRequestIn);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            switch (requestCode) {
                case PICK_IMAGE_REQUEST1:
                    Uri mImageUri1 = data.getData();

                    uris.set(0, mImageUri1);
                    Glide.with(this).load(mImageUri1).into(carImage1);
                    carImage2.setVisibility(View.VISIBLE);
                    break;

                case PICK_IMAGE_REQUEST2:
                    Uri mImageUri2 = data.getData();

                    uris.set(1, mImageUri2);
                    Glide.with(this).load(mImageUri2).into(carImage2);
                    carImage3.setVisibility(View.VISIBLE);
                    break;

                case PICK_IMAGE_REQUEST3:
                    Uri mImageUri3 = data.getData();

                    uris.set(2, mImageUri3);
                    Glide.with(this).load(mImageUri3).into(carImage3);
                    carImage4.setVisibility(View.VISIBLE);
                    break;

                case PICK_IMAGE_REQUEST4:
                    Uri mImageUri4 = data.getData();


                    uris.set(3, mImageUri4);
                    Glide.with(this).load(mImageUri4).into(carImage4);
                    carImage5.setVisibility(View.VISIBLE);
                    break;

                case PICK_IMAGE_REQUEST5:
                    Uri mImageUri5 = data.getData();


                    uris.set(4, mImageUri5);
                    Glide.with(this).load(mImageUri5).into(carImage5);
                    carImage6.setVisibility(View.VISIBLE);
                    break;

                case PICK_IMAGE_REQUEST6:
                    Uri mImageUri6 = data.getData();


                    uris.set(5, mImageUri6);
                    Glide.with(this).load(mImageUri6).into(carImage6);
                    carImage7.setVisibility(View.VISIBLE);
                    break;

                case PICK_IMAGE_REQUEST7:
                    Uri mImageUri7 = data.getData();


                    uris.set(6, mImageUri7);
                    Glide.with(this).load(mImageUri7).into(carImage7);
                    carImage8.setVisibility(View.VISIBLE);
                    break;

                case PICK_IMAGE_REQUEST8:
                    Uri mImageUri8 = data.getData();

                    uris.set(7, mImageUri8);
                    Glide.with(this).load(mImageUri8).into(carImage8);
                    carImage9.setVisibility(View.VISIBLE);
                    break;

                case PICK_IMAGE_REQUEST9:
                    Uri mImageUri9 = data.getData();


                    uris.set(8, mImageUri9);
                    Glide.with(this).load(mImageUri9).into(carImage9);
                    carImage10.setVisibility(View.VISIBLE);
                    break;

                case PICK_IMAGE_REQUEST10:
                    Uri mImageUri10 = data.getData();


                    uris.set(9, mImageUri10);
                    Glide.with(this).load(mImageUri10).into(carImage10);
                    break;
            }
        }

    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    public void addFiles(final CollectionReference ratersdb, final Car newCarIn, final DocumentReference docRefIn) {

        //add the image URLs to the new Car DB reference
        for (int i = 0; i < uris.size(); i++) {
            if (uris.get(i) != null) {
                final StorageReference fileReference = mStorageRef.child(System.currentTimeMillis()
                        + "." + getFileExtension(uris.get(i)));
                final int finalI = i;
                int finalI1 = i;
                fileReference.putFile(uris.get(i)).addOnSuccessListener(taskSnapshot -> fileReference.getDownloadUrl()
                        .addOnSuccessListener(uri -> {
                            Log.d("", "onSuccess: uri= " + uri.toString());
                            newCarIn.addImageUrl(finalI1, uri.toString());
                            docRefIn.update("carImageUrls", FieldValue.arrayUnion(uri.toString()));
                            if (finalI == uris.size() - 1) {
                                updateRaterCars(ratersdb, newCarIn, docRefIn);
                            }

                        })).addOnCompleteListener(task -> {
                    if (uris.get(finalI + 1) == null) {
                        updateRaterCars(ratersdb, newCarIn, docRefIn);
                    }
                });
            }
        }


    }

    public void updateRaterCars(final CollectionReference raters, final Car newCarIn, final DocumentReference docRefIn) {
        final NonRatedCar nRCar = new NonRatedCar(newCarIn.getDbID());


        //add the new car to every raters "non rated cars" database
        raters.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    int i = 0;
                    for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                        DocumentReference carInD = documentSnapshot.getReference().collection("nonRatedCars").document(docRefIn.getId());
                        carInD.set(nRCar);
                        i++;
                    }
                    if (i == queryDocumentSnapshots.getDocuments().size()) {
                        Intent intent = new Intent(AddingCarActivity.this, MainActivity.class);
                        intent.putExtra(SignUpActivity.EMAIL_EXTRA, emailIn);
                        startActivity(intent);
                    }

                });


    }

    private Owner createNewOwner() {

        return new Owner(emailIn, usernameIn);
    }*/

