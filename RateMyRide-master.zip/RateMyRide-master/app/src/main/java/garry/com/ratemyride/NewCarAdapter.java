package garry.com.ratemyride;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import java.text.DecimalFormat;

public class NewCarAdapter extends FirestoreRecyclerAdapter<Car, NewCarAdapter.NewCarHolder> {

    private OnItemCLickListener mListener;

    public interface OnItemCLickListener {
        void onItemClick(int position);
    }

    void setOnItemClickListener(OnItemCLickListener listener) {
        mListener = listener;
    }

    NewCarAdapter(@NonNull FirestoreRecyclerOptions<Car> options) {
        super(options);
    }


    @SuppressLint("SetTextI18n")
    @Override
    protected void onBindViewHolder(@NonNull final NewCarAdapter.NewCarHolder holder, int position, @NonNull final Car model) {

        DecimalFormat df = new DecimalFormat("#00.##");

        if (model.getCarImageUrls().size() > 0) {
            holder.vUsername.setText(model.owner.getUsername());
            holder.vRating.setText(String.valueOf(df.format((model.getPosRatings() / model.getNumOfRatings()) * 100)) + "%");
            Glide.with(holder.vCarImage.getContext())
                    .load(model.getCarImageUrl(0))
                    .placeholder(R.drawable.placeholder)
                    .fitCenter()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(holder.vCarImage);

        } else {
            getSnapshots().getSnapshot(position).getReference().delete();
        }

    }

    @NonNull
    @Override


    public NewCarAdapter.NewCarHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rated_card_layout,
                parent, false);
        return new NewCarAdapter.NewCarHolder(v, mListener);
    }


    static class NewCarHolder extends RecyclerView.ViewHolder {


        TextView vUsername;
        ImageView vCarImage;
        TextView vRating;

        NewCarHolder(@NonNull View itemViewIn, final OnItemCLickListener listener) {
            super(itemViewIn);

            vUsername = itemViewIn.findViewById(R.id.txtUsername2);
            vCarImage = itemViewIn.findViewById(R.id.carImageView);
            vRating = itemView.findViewById(R.id.txtRating2);


            itemViewIn.setOnClickListener(v -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(position);
                    }
                }
            });
        }


    }


}
